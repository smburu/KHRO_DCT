from django.apps import AppConfig


class ElementsConfig(AppConfig):
    name = 'elements'
