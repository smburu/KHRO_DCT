from django.apps import AppConfig


class ResearchConfig(AppConfig):
    name = 'research'
