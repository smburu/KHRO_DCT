from django.apps import AppConfig


class CommonInfoConfig(AppConfig):
    name = 'common_info'
