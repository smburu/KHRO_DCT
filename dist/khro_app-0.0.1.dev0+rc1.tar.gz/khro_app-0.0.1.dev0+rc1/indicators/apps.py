from django.apps import AppConfig


class IndicatorsConfig(AppConfig):
    name = 'indicators'
