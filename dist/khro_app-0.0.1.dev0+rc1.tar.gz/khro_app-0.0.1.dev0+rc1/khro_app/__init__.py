__version__ = '0.0.1.dev+rc1'

VERSION = (0, 0, 1, 'dev', 'rc1')
