This is a Django application called KHRO datacapture tool (DCT) developed for thr Ministry of Health (Kenya). 
The tool has been developed by Dr. Stephen Mburu and validated by Daniel Mbugua, Software Enginees and Django Expert.
