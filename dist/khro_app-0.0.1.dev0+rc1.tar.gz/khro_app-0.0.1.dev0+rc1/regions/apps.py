from django.apps import AppConfig


class RegionsConfig(AppConfig):
    name = 'regions'
